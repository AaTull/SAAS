// Menu.js
import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Utensils,
  Soup,
  Salad,
  Sandwich,
  CupSoda,
  IceCream,
  ChefHat,
  ShoppingBag
} from "lucide-react";
const getCategoryIcon = (category) => {
  switch (category.toLowerCase()) {
    case "all":
      return <ChefHat size={16} className="mr-1" />;
    case "starters":
      return <Soup size={16} className="mr-1" />;
    case "salads":
      return <Salad size={16} className="mr-1" />;
    case "main course":
      return <Utensils size={16} className="mr-1" />;
    case "drinks":
      return <CupSoda size={16} className="mr-1" />;
    case "desserts":
      return <IceCream size={16} className="mr-1" />;
    default:
      return <Utensils size={16} className="mr-1" />;
  }
};


function Menu({ items, onAdd, onRemove, cartItems, totalItems, totalPrice }) {
  const [search, setSearch] = useState("");
  const [onlyVeg, setOnlyVeg] = useState(false);
  const [activeCategory, setActiveCategory] = useState("All");

  const categories = ["All", ...items.map((section) => section.category)];

  return (
    
    <div className="min-h-screen bg-white pb-24 font-sans">
      {/* Category Filter */}
      <div className="flex gap-3 overflow-x-auto no-scrollbar px-4 py-2 text-sm font-medium">
  {categories.map((cat, i) => (
  <button
    key={i}
    className={`flex items-center gap-1 px-3 py-1 text-sm rounded-full transition whitespace-nowrap
      ${
        activeCategory === cat
          ? "bg-orange-500 text-white"
          : "border border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
      }`}
    onClick={() => setActiveCategory(cat)}
  >
    {getCategoryIcon(cat)}
    {cat}
  </button>
))}

</div>


      {/* Search + Veg Toggle */}
      <div className="flex items-center justify-between px-4 py-3">
        <input
          type="text"
          placeholder="🔍 Search for dishes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-auto sm:w-2/3 px-4 py-2 text-sm border border-gray-300 rounded-full shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-400 transition"
          spellCheck={false}
        />

        <div className="flex flex-col items-center justify-center">
          <button
            onClick={() => setOnlyVeg(!onlyVeg)}
            className={`w-12 h-6 flex items-center rounded-full p-1 transition-all duration-300 
              ${onlyVeg ? "bg-green-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-all duration-300 
                ${onlyVeg ? "translate-x-6" : "translate-x-0"}`}
            ></div>
          </button>
          <span className="text-xs text-gray-700 font-medium mt-1">Only Veg</span>
        </div>
      </div>

      {/* Food Items by Category */}
      <div className="px-4 space-y-8">
        {items
          .filter((section) => activeCategory === "All" || section.category === activeCategory)
          .map((section, idx) => {
            const filteredItems = section.items.filter((item) => {
              const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
              const isVeg = !item.name.toLowerCase().includes("chicken") && !item.name.toLowerCase().includes("mutton");
              return matchesSearch && (!onlyVeg || isVeg);
            });

            if (filteredItems.length === 0) return null;

            return (
              <div key={idx}>
                <h2 className="text-xl font-semibold text-gray-800 mb-2">{section.category}</h2>
                <ul className="space-y-4">
                  {filteredItems.map((item) => {
                    const cartItem = cartItems.find((ci) => ci.id === item.id);

                    return (
                      <li
                        key={item.id}
                        className="flex justify-between items-start py-6 border-b"
                      >
                        {/* LEFT SIDE: Name, Price, Rating, Description */}
                        <div className="max-w-[65%]">
                          <div className="flex items-center gap-2 mb-1">
                            <span
                              className={`w-3 h-3 rounded-sm border flex items-center justify-center ${
                                item.veg ? "border-green-600" : "border-red-600"
                              }`}
                            >
                              <span
                                className={`w-2 h-2 rounded-full ${
                                  item.veg ? "bg-green-600" : "bg-red-600"
                                }`}
                              ></span>
                            </span>
                            <h3 className="text-base font-semibold text-gray-800">{item.name}</h3>
                          </div>

                          <p className="text-sm font-medium text-gray-900 mt-1">₹{item.price}</p>
                          <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                        </div>

                        {/* RIGHT SIDE: Image + ADD / Counter */}
                        <div className="relative w-24">
                          <img
                            src={item.image || "https://via.placeholder.com/100"}
                            alt={item.name}
                            className="w-24 h-20 object-cover rounded-lg"
                          />

                          <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-full px-2">
                            {cartItem && cartItem.quantity > 0 ? (
                              <div className="flex items-center justify-between bg-white shadow-md rounded-full px-2 h-8 w-full">
                                <button
                                  onClick={() => onRemove(item.id)}
                                  className="text-green-600 font-bold px-2 py-0.5 rounded-full hover:bg-green-100"
                                >
                                  −
                                </button>
                                <span className="text-sm font-semibold">{cartItem.quantity}</span>
                                <button
                                  onClick={() => onAdd(item)}
                                  className="text-green-600 font-bold px-2 py-0.5 rounded-full hover:bg-green-100"
                                >
                                  +
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => onAdd(item)}
                                className="w-full h-8 bg-white text-green-600 font-bold shadow-md rounded-full text-sm hover:bg-green-50 transition"
                              >
                                ADD
                              </button>
                            )}
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
      </div>

      {/* Floating Cart Summary */}
      {totalItems > 0 && (
        <Link
          to="/cart"
          className="fixed bottom-4 left-4 right-4 bg-green-600 text-white flex justify-between items-center px-6 py-4 shadow-xl rounded-full transition-all duration-300 hover:bg-green-700 z-50"
        >
          <div className="text-base sm:text-lg font-semibold">
            {totalItems} item{totalItems > 1 ? "s" : ""} | ₹{totalPrice}
          </div>

          <div className="flex items-center gap-1 text-base sm:text-lg font-semibold">
            <ShoppingBag size={24} color="white" />
            <span>View Cart</span>
            <span className="text-lg">›</span>
          </div>
        </Link>
      )}
    </div>
  );
}

export default Menu;
