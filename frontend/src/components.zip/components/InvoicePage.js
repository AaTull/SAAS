import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function InvoicePage() {
  const navigate = useNavigate();
  const order = JSON.parse(localStorage.getItem("currentOrder") || "{}");

  useEffect(() => {
    if (!order?.items || order.items.length === 0) {
      navigate("/"); // If accessed directly without an order
    }
  }, [order, navigate]);

  const subtotal = order.items?.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  const gst = subtotal * 0.05;
  const total = subtotal + gst;

  return (
    <div className="min-h-screen bg-white font-sans p-6 sm:p-10">
      <div className="max-w-3xl mx-auto border border-gray-200 rounded-lg p-6 shadow">
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-bold text-gray-800">Invoice</h1>
          <p className="text-sm text-gray-500">Thanks for your order!</p>
        </div>

        {/* Header Info */}
        <div className="flex justify-between mb-4 text-sm text-gray-600">
          <div>
            <p><span className="font-medium">Order ID:</span> {order.orderId}</p>
            <p><span className="font-medium">Bill No:</span> {order.orderId.replace("#ORD", "#INV")}</p>
          </div>
          <div>
            <p><span className="font-medium">Date:</span> {new Date(order.timestamp).toLocaleDateString()}</p>
            <p><span className="font-medium">Time:</span> {new Date(order.timestamp).toLocaleTimeString()}</p>
          </div>
        </div>

        {/* Items Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left border-t border-gray-200 mt-4">
            <thead>
              <tr className="text-gray-700 border-b border-gray-200">
                <th className="py-2 pr-4">Item</th>
                <th className="py-2 pr-4">Qty</th>
                <th className="py-2 pr-4">Price</th>
                <th className="py-2 pr-4">Total</th>
              </tr>
            </thead>
            <tbody>
              {order.items?.map((item) => (
                <tr key={item.id} className="border-b border-gray-100">
                  <td className="py-2 pr-4">{item.name}</td>
                  <td className="py-2 pr-4">{item.quantity}</td>
                  <td className="py-2 pr-4">₹{item.price}</td>
                  <td className="py-2 pr-4 font-medium">₹{item.price * item.quantity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Summary */}
        <div className="mt-6 text-right text-sm">
          <p className="mb-1"><span className="font-medium">Subtotal:</span> ₹{subtotal.toFixed(2)}</p>
          <p className="mb-1"><span className="font-medium">GST (5%):</span> ₹{gst.toFixed(2)}</p>
          <p className="text-lg font-bold mt-2"><span className="font-semibold">Total:</span> ₹{total.toFixed(2)}</p>
        </div>

        {/* Action */}
        <div className="mt-8 text-center">
          <button
            onClick={() => window.print()}
            className="bg-green-600 text-white px-6 py-2 rounded-full text-sm font-semibold hover:bg-green-700 transition"
          >
            Print Invoice
          </button>
        </div>
      </div>
    </div>
  );
}

export default InvoicePage;
