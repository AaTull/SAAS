// src/components/Header.js
import React from "react";

function Header({ hotel }) {
  return (
    <header className="sticky top-0 z-50 bg-white shadow px-4 py-3 font-sans">
      <div className="flex items-center justify-between">
        {/* Hotel Info */}
        <div className="flex flex-col">
          <span className="text-lg font-semibold text-gray-800 leading-tight">
            {hotel.name}
          </span>
          <span className="text-sm text-gray-500">
            {hotel.location} • ⭐ {hotel.rating}
          </span>
        </div>

        {/* HungryScan Logo */}
        <div className="flex items-center gap-2">
          <img
            src="/images/hungryscan.png" // Place logo in public/images folder
            alt="HungryScan"
            className="w-8 h-8 object-contain"
          />
          <span className="text-xs text-gray-500 font-medium hidden sm:block">
            Powered by HungryScan
          </span>
        </div>
      </div>
    </header>
  );
}

export default Header;
