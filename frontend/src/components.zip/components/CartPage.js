import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Trash2, Minus, Plus } from "lucide-react";

function CartPage({ cart, onRemove, onIncrease, onDecrease, onPlaceOrder }) {
  const [billNumber, setBillNumber] = useState("");

  useEffect(() => {
    const storedOrder = JSON.parse(localStorage.getItem("currentOrder"));
    if (storedOrder?.orderId) {
      setBillNumber(storedOrder.orderId);
    } else {
      const newBill = `#INV-${Date.now().toString().slice(-6)}`;
      setBillNumber(newBill);
    }
  }, []);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const gstRate = 0.05;
  const gstAmount = subtotal * gstRate;
  const total = subtotal + gstAmount;

  // Save latest cart to localStorage (so it persists)
  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("currentOrder") || "{}");
    localStorage.setItem(
      "currentOrder",
      JSON.stringify({
        ...stored,
        items: cart,
        totalPrice: total,
        totalItems: cart.reduce((sum, i) => sum + i.quantity, 0),
      })
    );
  }, [cart, total]);

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Top Navigation Bar */}
      <div className="sticky top-0 z-40 bg-gradient-to-r from-green-50 to-white px-4 py-3 shadow flex items-center justify-between">
        <Link
          to="/"
          className="flex items-center text-green-700 font-medium text-sm hover:underline"
        >
          <ArrowLeft className="w-5 h-5 mr-2" /> Back to Menu
        </Link>
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold">
            <span className="text-orange-500">Hungry</span>
            <span className="text-black">Scan</span>
          </span>
        </div>
      </div>

      <div className="p-4 pb-32">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex flex-col gap-1">
            <p className="text-sm text-gray-500">
              Bill No: <span className="font-medium">{billNumber}</span>
            </p>
          </div>
        </div>

        {/* Empty Cart */}
        {cart.length === 0 ? (
          <p className="text-gray-500 text-center mt-10">Your cart is empty.</p>
        ) : (
          <>
            <ul className="space-y-4">
              {cart.map((item, index) => (
                <li
                  key={index}
                  className="grid grid-cols-[auto_1fr_auto] gap-4 items-center bg-green-50/40 rounded-xl p-4 shadow-sm border border-green-100"
                >
                  {/* Image */}
                  <div className="w-20 h-20 rounded-md overflow-hidden border border-gray-200">
                    <img
                      src={item.image || "https://via.placeholder.com/64"}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex flex-col justify-between">
                    <h3 className="text-base font-semibold text-gray-800 mb-1">{item.name}</h3>
                    <p className="text-sm text-gray-500 mb-2">
                      ₹{item.price} × {item.quantity} = ₹{item.price * item.quantity}
                    </p>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => onDecrease(item.id)}
                        className="p-1.5 rounded-full bg-white border hover:bg-gray-100"
                      >
                        <Minus size={16} />
                      </button>
                      <span className="font-semibold text-sm">{item.quantity}</span>
                      <button
                        onClick={() => onIncrease(item.id)}
                        className="p-1.5 rounded-full bg-white border hover:bg-gray-100"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>

                  {/* Remove Button */}
                  <div>
                    <button
                      onClick={() => onRemove(item.id)}
                      className="p-2 text-red-500 hover:text-red-600"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </li>
              ))}
            </ul>

            {/* Summary */}
            <div className="mt-8 p-4 bg-green-50 rounded-lg shadow-inner border border-green-100">
              <h3 className="text-sm font-semibold text-green-800 mb-2">Bill Summary</h3>
              <div className="flex justify-between text-sm mb-1">
                <span>Subtotal</span>
                <span>₹{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm mb-1">
                <span>GST (5%)</span>
                <span>₹{gstAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-base font-bold mt-2">
                <span>Total</span>
                <span>₹{total.toFixed(2)}</span>
              </div>
            </div>

            {/* Place Order Button */}
            <div className="fixed bottom-0 left-0 right-0 bg-white border-t px-6 py-4 flex justify-between items-center shadow-md rounded-t-2xl">
              <span className="text-lg font-bold text-gray-800">
                Total: ₹{total.toFixed(2)}
              </span>
              <button
                onClick={onPlaceOrder}
                className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-full font-semibold text-sm shadow flex items-center gap-2 transition-all duration-200"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
                Place Order
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default CartPage;
